"""Integration tests.

Use API for running tests on all the available models.
"""

# Copyright (C) 2023-2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
