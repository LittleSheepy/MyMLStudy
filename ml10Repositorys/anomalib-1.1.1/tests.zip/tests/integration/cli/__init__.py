"""Integration tests.

Currently only the CLI is tested and the trained models are used for the unit tests.
"""

# Copyright (C) 2023-2024 Intel Corporation
# SPDX-License-Identifier: Apache-2.0
