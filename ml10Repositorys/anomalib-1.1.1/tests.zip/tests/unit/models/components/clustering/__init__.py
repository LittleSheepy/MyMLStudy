"""Tests for clustering components."""
